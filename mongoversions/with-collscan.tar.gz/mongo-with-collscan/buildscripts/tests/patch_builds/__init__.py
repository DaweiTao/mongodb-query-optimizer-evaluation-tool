"""Unit tests for buildscripts.patch_builds patckage."""
